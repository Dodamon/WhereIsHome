package com.ssafy.happyhouse.util;

public class MyException extends Exception {

	public MyException() {
		super();
	}

	public MyException(String message) {
		super(message);
	}  
	
}
