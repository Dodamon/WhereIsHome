package com.ssafy.happyhouse.member.dto;

public enum Role {
	ADMIN, USER;
}
